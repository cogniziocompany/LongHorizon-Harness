# fixture-pr-pass

A tiny repo used to review a clean PR.
